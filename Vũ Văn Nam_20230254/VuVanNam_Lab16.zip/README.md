LAB 16 - XÂY DỰNG HỆ THỐNG XỬ LÝ ĐƠN HÀNG ĐA NỀN TẢNG
1. Cài JDK 21, Maven, MySQL 8 và Tomcat 10.
2. Chạy database/database.sql. Nếu mật khẩu MySQL khác 123456, sửa trong 3 project.
3. Jakarta EE: mvn clean package -> deploy WAR vào Tomcat 10.
4. Swing: mvn compile exec chưa cấu hình plugin; chạy class WarehouseApp từ IDE.
5. Spring Boot: mvn spring-boot:run, mở http://localhost:8080.
Luồng demo: Customer tạo/quan sát đơn -> Swing nhận và PACKED -> Spring Boot APPROVED -> Customer theo dõi.
