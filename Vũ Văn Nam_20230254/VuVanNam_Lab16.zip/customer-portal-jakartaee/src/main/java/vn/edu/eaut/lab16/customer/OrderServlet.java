package vn.edu.eaut.lab16.customer;
import jakarta.servlet.annotation.WebServlet;
import jakarta.servlet.http.*;
import jakarta.servlet.ServletException;
import java.io.IOException;
import java.sql.*;

@WebServlet("/orders")
public class OrderServlet extends HttpServlet {
  private final String URL="jdbc:mysql://localhost:3306/order_management?useSSL=false&serverTimezone=Asia/Ho_Chi_Minh";
  protected void doGet(HttpServletRequest req,HttpServletResponse resp)throws IOException,ServletException{
    resp.setContentType("text/html;charset=UTF-8");
    try(Connection c=DriverManager.getConnection(URL,"root","123456");
        PreparedStatement p=c.prepareStatement("SELECT id,status,total_amount,created_at FROM orders ORDER BY id DESC");
        ResultSet r=p.executeQuery()){
      var out=resp.getWriter(); out.println("<h1>Customer Portal - Đơn hàng</h1><table border=1>");
      out.println("<tr><th>ID</th><th>Trạng thái</th><th>Tổng tiền</th><th>Ngày tạo</th></tr>");
      while(r.next()) out.printf("<tr><td>%d</td><td>%s</td><td>%,.0f</td><td>%s</td></tr>",
        r.getLong(1),r.getString(2),r.getDouble(3),r.getTimestamp(4));
      out.println("</table>");
    }catch(Exception e){throw new ServletException(e);}
  }
}