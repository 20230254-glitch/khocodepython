package vn.edu.eaut.lab16.warehouse;
import javax.swing.*; import javax.swing.table.DefaultTableModel; import java.awt.*; import java.sql.*;

public class WarehouseApp extends JFrame {
 String URL="jdbc:mysql://localhost:3306/order_management?useSSL=false&serverTimezone=Asia/Ho_Chi_Minh";
 DefaultTableModel model=new DefaultTableModel(new String[]{"Mã đơn","Khách hàng","Trạng thái","Tổng tiền"},0);
 JTable table=new JTable(model);
 public WarehouseApp(){setTitle("Warehouse Desktop - Quản lý kho");setSize(850,500);setLocationRelativeTo(null);
  JButton refresh=new JButton("Tải đơn"); JButton process=new JButton("Xử lý / Đóng gói");
  JPanel top=new JPanel();top.add(refresh);top.add(process);add(top,BorderLayout.NORTH);add(new JScrollPane(table));
  refresh.addActionListener(e->load()); process.addActionListener(e->packOrder()); load();
 }
 void load(){model.setRowCount(0); try(Connection c=DriverManager.getConnection(URL,"root","123456");
  PreparedStatement p=c.prepareStatement("SELECT o.id,u.full_name,o.status,o.total_amount FROM orders o JOIN users u ON u.id=o.customer_id ORDER BY o.id DESC");
  ResultSet r=p.executeQuery()){while(r.next())model.addRow(new Object[]{r.getLong(1),r.getString(2),r.getString(3),r.getDouble(4)});}
  catch(Exception e){JOptionPane.showMessageDialog(this,e.getMessage());}}
 void packOrder(){int row=table.getSelectedRow();if(row<0)return;long id=(long)model.getValueAt(row,0);
  try(Connection c=DriverManager.getConnection(URL,"root","123456")){c.setAutoCommit(false);
   PreparedStatement q=c.prepareStatement("UPDATE orders SET status='PACKED',version=version+1 WHERE id=? AND status IN ('PENDING','PROCESSING')");
   q.setLong(1,id);q.executeUpdate(); c.commit();load();
  }catch(Exception e){JOptionPane.showMessageDialog(this,e.getMessage());}}
 public static void main(String[]a){SwingUtilities.invokeLater(()->new WarehouseApp().setVisible(true));}
}