package vn.edu.eaut.lab16.management;
import org.springframework.boot.SpringApplication;import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.web.bind.annotation.*;import org.springframework.jdbc.core.JdbcTemplate;import org.springframework.context.annotation.Bean;
import org.springframework.security.config.annotation.web.builders.HttpSecurity;import org.springframework.security.web.SecurityFilterChain;

@SpringBootApplication public class ManagementApplication{
 public static void main(String[]a){SpringApplication.run(ManagementApplication.class,a);}
 @Bean SecurityFilterChain security(HttpSecurity h)throws Exception{return h.csrf(c->c.disable()).authorizeHttpRequests(a->a.requestMatchers("/").permitAll().anyRequest().authenticated()).httpBasic(x->{}).build();}
 @RestController @RequestMapping("/api") static class Api{
  private final JdbcTemplate db; Api(JdbcTemplate db){this.db=db;}
  @GetMapping("/orders") Object orders(){return db.queryForList("SELECT * FROM orders ORDER BY id DESC");}
  @PostMapping("/orders/{id}/approve") String approve(@PathVariable long id){db.update("UPDATE orders SET status='APPROVED',version=version+1 WHERE id=? AND status='PACKED'",id);return "Đã phê duyệt đơn "+id;}
 }
}