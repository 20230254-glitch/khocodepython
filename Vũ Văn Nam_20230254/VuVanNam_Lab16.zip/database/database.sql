CREATE DATABASE IF NOT EXISTS order_management CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE order_management;

CREATE TABLE users (
 id BIGINT PRIMARY KEY AUTO_INCREMENT, username VARCHAR(50) UNIQUE NOT NULL,
 password VARCHAR(255) NOT NULL, full_name VARCHAR(100) NOT NULL,
 role ENUM('CUSTOMER','WAREHOUSE','MANAGER','ADMIN') NOT NULL
);
CREATE TABLE products (
 id BIGINT PRIMARY KEY AUTO_INCREMENT, name VARCHAR(150) NOT NULL,
 price DECIMAL(12,2) NOT NULL, stock INT NOT NULL DEFAULT 0, active BOOLEAN DEFAULT TRUE
);
CREATE TABLE orders (
 id BIGINT PRIMARY KEY AUTO_INCREMENT, customer_id BIGINT NOT NULL,
 status VARCHAR(30) NOT NULL DEFAULT 'PENDING', total_amount DECIMAL(12,2) NOT NULL,
 version BIGINT NOT NULL DEFAULT 0, created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP ON UPDATE CURRENT_TIMESTAMP,
 FOREIGN KEY (customer_id) REFERENCES users(id)
);
CREATE TABLE order_items (
 id BIGINT PRIMARY KEY AUTO_INCREMENT, order_id BIGINT NOT NULL,
 product_id BIGINT NOT NULL, quantity INT NOT NULL, unit_price DECIMAL(12,2) NOT NULL,
 FOREIGN KEY(order_id) REFERENCES orders(id), FOREIGN KEY(product_id) REFERENCES products(id)
);
CREATE TABLE order_history (
 id BIGINT PRIMARY KEY AUTO_INCREMENT, order_id BIGINT NOT NULL,
 old_status VARCHAR(30), new_status VARCHAR(30) NOT NULL,
 changed_by BIGINT, note VARCHAR(255), changed_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
 FOREIGN KEY(order_id) REFERENCES orders(id)
);

INSERT INTO users(username,password,full_name,role) VALUES
('customer','123456','Nguyễn Văn Khách','CUSTOMER'),
('warehouse','123456','Nhân viên kho','WAREHOUSE'),
('manager','123456','Quản lý','MANAGER'),
('admin','123456','Quản trị viên','ADMIN');

INSERT INTO products(name,price,stock) VALUES
('Laptop ASUS Vivobook',15990000,20),
('Chuột Logitech',450000,50),
('Bàn phím cơ',890000,30),
('Tai nghe Bluetooth',1250000,25);

INSERT INTO orders(customer_id,status,total_amount) VALUES
(1,'PENDING',16840000);
INSERT INTO order_items(order_id,product_id,quantity,unit_price) VALUES
(1,1,1,15990000),(1,2,2,450000);
